package com.swag.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.swag.qa.util.SwagUtil;
//import org.openqa.selenium.support.events.EventFiringWebDriver;

//import com.crm.qa.util.TestUtil;
//import com.crm.qa.util.WebEventListener;


public class Swagbase {
		public static WebDriver driver;
		public static Properties prop;
		//public  static EventFiringWebDriver e_driver;
		//public static WebEventListener eventListener;
		
		public Swagbase(){
			try {
				prop = new Properties();
				FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+ "/src/main/java/com/swag"
						+ "/qa/config/config.properties");
				prop.load(ip);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		public static void initialization(){
			String browserName = prop.getProperty("browser");
			
			if(browserName.equals("chrome")){
				System.setProperty("webdriver.chrome.driver", "D:\\Selenium_Pra\\SwagLabs\\src\\Driver\\chromedriver.exe");	
				driver = new ChromeDriver(); 
			}
			
			else if(browserName.equals("FF")){
				System.setProperty("webdriver.gecko.driver", "C:\\Users\\Akshita\\Downloads\\Driver\\geckodriver.exe");	
				driver = new FirefoxDriver(); 
			}
			else if(browserName.equals("edge")){
				System.setProperty("webdriver.edge.driver", "D:\\Selenium_Pra\\SwagLabs\\src\\Driver\\Edgedriver.exe");	
				driver = new EdgeDriver(); 
			}
			
			
			//e_driver = new EventFiringWebDriver(driver);
			// Now create object of EventListerHandler to register it with EventFiringWebDriver
			//eventListener = new WebEventListener();
			//e_driver.register(eventListener);
			//driver = e_driver;
			
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(SwagUtil.SHORT_TIME_OUT));
			driver.manage().timeouts().getPageLoadTimeout();
			driver.get(prop.getProperty("url"));
			
		}
		
		
		
		
		

}
