package com.swag.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.swag.qa.base.Swagbase;

public class CheckoutPage extends Swagbase {
	
	 @FindBy(xpath = "//*[@id='checkout']") 
	  WebElement checkout;
	 
	  @FindBy(xpath="//*[text()='Products']")
			WebElement SwagLogo;
	 
	// Initializing the Page Objects:
		public CheckoutPage() {
			PageFactory.initElements(driver, this);
		}
		
		public String verifycheckoutPageTitle(){
			return driver.getTitle();
		}	
		
		public boolean validateSwagImage(){
			return SwagLogo.isDisplayed();
		}
	
	public CheckoutPage VerifyCheckout() {
		checkout.isEnabled();
		return new CheckoutPage();
	}

}
