package com.swag.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//import com.swag.qa.pages.ProductPage;
//import com.qa.opencart.constants.AppConstants;
//import com.qa.opencart.utils.ElementUtil;
import com.swag.qa.base.Swagbase;

//import io.qameta.allure.Step;

public class LoginPage extends Swagbase {

	/*
	 * private WebDriver driver; private ElementUtil eleUtil;
	 * 
	 * // 1. private By locators - page locators private By uid =
	 * By.id("user-name"); private By password = By.id("password"); private By
	 * loginBtn = By.xpath("//input[@id='login-button']"); //private By
	 * forgotPwdLink = By.linkText("Forgotten Password"); //private By registerLink
	 * = By.linkText("Register"); private By AppLogo =
	 * By.xpath("//*[@class='app_logo']");
	 * 
	 * 
	 * 
	 * // 2. public Page Constructor public LoginPage(WebDriver driver) {
	 * this.driver = driver; eleUtil = new ElementUtil(driver); }
	 * 
	 * // 3. public Page actions/methods
	 * 
	 * @Step("....getting login page title....") public String getLoginPageTitle() {
	 * String title = eleUtil.waitForTitleIs(AppConstants.LOGIN_PAGE_TITLE,
	 * AppConstants.SHORT_TIME_OUT); System.out.println("Login Page title is: " +
	 * title); return title; }
	 * 
	 * //@Step("....getting login page url....") //public String getLoginPageURL() {
	 * // String url =
	 * eleUtil.waitForURLContains(AppConstants.LOGIN_PAGE_URL_FRACTION,
	 * AppConstants.SHORT_TIME_OUT); // System.out.println("Login Page url is: " +
	 * url); // return url; //}
	 * 
	 * //@Step("....is forgot pwd link exist or not....") //public boolean
	 * isForgotPwdLinkExist() { // return
	 * eleUtil.waitForElementVisible(forgotPwdLink,
	 * AppConstants.MEDIUM_TIME_OUT).isDisplayed(); //}
	 * 
	 * @Step("login to app with username: {0} and password: {1}") public LoginPage
	 * doLogin(String username, String pwd) { System.out.println("App creds are: " +
	 * username + ":" + pwd); eleUtil.waitForElementVisible(uid,
	 * AppConstants.MEDIUM_TIME_OUT).sendKeys(username);
	 * eleUtil.doSendKeys(password, pwd); eleUtil.doClick(loginBtn); return new
	 * LoginPage(driver); }
	 * 
	 * //@Step("navigating to register page....") //public RegisterPage
	 * navigateToRegisterPage() { // eleUtil.waitForElementVisible(registerLink,
	 * AppConstants.SHORT_TIME_OUT).click(); // return new RegisterPage(driver); //}
	 * 
	 * @Step("Swag Labs logo in Home page...") public boolean isAppLogoExist() {
	 * return eleUtil.waitForElementPresence(AppLogo,
	 * AppConstants.MEDIUM_TIME_OUT).isDisplayed(); }
	 * 
	 * 
	 * 
	 */
	//Page Factory - OR:
		@FindBy(id="user-name")
		WebElement username;
		
		@FindBy(id="password")
		WebElement password;
		
		@FindBy(xpath="//input[@id='login-button']")
		WebElement loginBtn;
		
		//@FindBy(xpath="//button[contains(text(),'Sign Up')]")
		//WebElement signUpBtn;
		
		
		
		//Initializing the Page Objects:
		public LoginPage(){
			PageFactory.initElements(driver, this);
		}
		
		//Actions:
		public String validateLoginPageTitle(){
			return driver.getTitle();
		}
		
		
		
		public ProductPage login(String un, String pwd){
			username.sendKeys(un);
			password.sendKeys(pwd);
			//loginBtn.click();
			    	JavascriptExecutor js = (JavascriptExecutor)driver;
			    	js.executeScript("arguments[0].click();", loginBtn);    	
			  	
			    		
			return new ProductPage();
		}
}
		
