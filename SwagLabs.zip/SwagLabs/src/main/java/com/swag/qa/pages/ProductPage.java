package com.swag.qa.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.swag.qa.base.Swagbase;

public class ProductPage extends Swagbase{
	
	  @FindBy(xpath = "//span[contains(text(),'Products')]")	
	   WebElement userProduct;
	  
	  @FindBy(xpath = "//*[text()='Sauce Labs Bike Light']")
	  WebElement ProductBikeLight;
	  
	  
	  @FindBy(xpath = "//*[@class='inventory_item']")
	  List<WebElement> AllInventoryItem;
	  
	  
	  @FindBy(xpath = "//*[@class='inventory_item_price']") 
	  WebElement AllInventoryPrice;
	  
	  @FindBy(xpath = "//*[@class='inventory_item_name']") 
	  WebElement AllInventoryItemName;
	  
	  @FindBy(xpath = "//option[@value='az']") 
	  WebElement SortByAtoZ;
	
	  @FindBy(xpath = "//option[@value='za']") 
	  WebElement SortByZtoA;
	  
	  @FindBy(xpath = "//option[@value='lohi']") 
	  WebElement SortByLowtoHightPrice;
	  
	  @FindBy(xpath = "//option[@value='hilo']") 
	  WebElement SortByHightoLowPrice;
	
	
	    
	  
	  @FindBy(xpath = "//*[@id='add-to-cart-sauce-labs-backpack']") 
	  WebElement AddtocartItem;
	  
	  @FindBy(xpath = "//*[@class='shopping_cart_badge']") 
	  WebElement Shoppingcartbadge;
	  
	 
	  
	  @FindBy(xpath="//*[text()='Products']")
		WebElement SwagLogo;
	 
	// Initializing the Page Objects:
	public ProductPage() {
		PageFactory.initElements(driver, this);
	}
	
	public String verifyProductPageTitle(){
		return driver.getTitle();
	}	
	
	public boolean validateSwagImage(){
		return SwagLogo.isDisplayed();
	}
	
	public boolean verifyProductBikeLight() {
		return ProductBikeLight.isDisplayed();
	}
	public boolean verifyProductList() {
		return AllInventoryItem.size()>0;
	}

	  public ProductPage SortByAtoZTest() {
		  SortByAtoZ.click();
		  return new ProductPage();
	    }
	  public ProductPage SortByZtoATest() {
		  SortByZtoA.click();
		  return new ProductPage();
	    }

	    public ProductPage SortByLowtoHightPriceTest() {
	    	SortByLowtoHightPrice.click();
	    	return new ProductPage();
	    }
	        
	        public ProductPage SortByHightoLowPrice() {
	        	SortByHightoLowPrice.click();
	        	return new ProductPage();
	        }
	
	public void Clickaddtocart() {
		AddtocartItem.click();		
	}
	public CheckoutPage Clickbadge() {
		Shoppingcartbadge.click();
		return new CheckoutPage();
	}
	


	}
	

