package com.swag.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.swag.qa.base.Swagbase;
import com.swag.qa.pages.CheckoutPage;
import com.swag.qa.pages.LoginPage;
import com.swag.qa.pages.ProductPage;

public class CheckOutPageTest extends Swagbase{
	
	LoginPage loginPage;
	CheckoutPage checkoutpage;
	
	public CheckOutPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginPage = new LoginPage();
		//checkoutpage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
			}
	
	@Test(priority=1)
	public void VerifySwagTitleTest(){
		String title = checkoutpage.verifycheckoutPageTitle();				
		Assert.assertEquals(title, "Swag Labs","Product page title not matched");
		
	}
	@Test(priority=2)
	public void SwagLogoImageTest(){
		boolean flag = checkoutpage.validateSwagImage();
		Assert.assertTrue(flag);
	}

}
