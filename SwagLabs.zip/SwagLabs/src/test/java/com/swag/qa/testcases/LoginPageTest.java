package com.swag.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.swag.qa.base.Swagbase;
import com.swag.qa.pages.ProductPage;
import com.swag.qa.pages.LoginPage;
import com.swag.qa.base.Swagbase;

public class LoginPageTest extends Swagbase{
	LoginPage loginPage;
	ProductPage productPage;
	
	public LoginPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginPage = new LoginPage();
			}
	
	@Test(priority=1)
	public void loginPageTitleTest(){
		String title = loginPage.validateLoginPageTitle();
		Assert.assertEquals(title, "Swag Labs");
	}
	

	
	@Test(priority=3)
	public void loginTest(){
		productPage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
	}	
	
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}	

}
