package com.swag.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.swag.qa.base.Swagbase;
import com.swag.qa.pages.CheckoutPage;
import com.swag.qa.pages.LoginPage;
import com.swag.qa.pages.ProductPage;

public class ProductPageTest extends Swagbase {
	LoginPage loginPage;
	ProductPage productPage;
	
	public ProductPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginPage = new LoginPage();
		productPage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
			}
	
	@Test(priority=1)
	public void VerifySwagTitleTest(){
		String title = productPage.verifyProductPageTitle();				
		Assert.assertEquals(title, "Swag Labs","Product page title not matched");
		
	}
	@Test(priority=2)
	public void SwagLogoImageTest(){
		boolean flag = productPage.validateSwagImage();
		Assert.assertTrue(flag);
	}
	@Test(priority=2)
	public void VerifyProductListTest(){
		boolean flag = productPage.verifyProductList();
		Assert.assertTrue(flag);
	}
	@Test(priority=3)
	public void VerifySortingAtoZ(){
		ProductPage sort = productPage.SortByAtoZTest();
		Assert.assertTrue(true);
		boolean flag = productPage.verifyProductList();
		Assert.assertTrue(flag);
	}
	@Test(priority=4)
	public void VerifySortingZtoA(){
		ProductPage sort = productPage.SortByZtoATest();
		Assert.assertTrue(true);
		boolean flag = productPage.verifyProductList();
		Assert.assertTrue(flag);
	}
	@Test(priority=5)
	public void VerifyPriceLowtoHighTest(){
		ProductPage sort = productPage.SortByLowtoHightPriceTest();
		Assert.assertTrue(true);
		boolean flag = productPage.verifyProductList();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=6)
	public void VerifyPriceHightoLowTest(){
		ProductPage sort = productPage.SortByHightoLowPrice();
		Assert.assertTrue(true);
		boolean flag = productPage.verifyProductList();
		Assert.assertTrue(flag);
	}
	@Test(priority=7)
	public void ClickaddtocartTest(){
		productPage.Clickaddtocart();
		}
	@Test(priority=8)
	public void ClickonbadgeTest(){
		 CheckoutPage clicktobadge = productPage.Clickbadge();
		}
		
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}	


}
